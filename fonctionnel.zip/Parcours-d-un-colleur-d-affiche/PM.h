#ifndef _PM_H_
#define _PM_H_
double factorielle(int n);
void Pcirculaire (string tab[],int g, int tailletab);
void combinaison (string nom[],int nec,int tailletab);
double bazinga();
double distance (double x1, double y1, double x2, double y2);
void intro ();

#endif

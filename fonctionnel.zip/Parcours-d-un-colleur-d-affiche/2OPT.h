#ifndef _2OPT_H_
#define _2OPT_H_
#include <vector>
#include "recuit.h"
void dopt(int P[][2] , int n //a completer
          );
vector <int> initiordre(const int n );
void Tswap(int i, int k,const int & n,vector <int> ordre ,vector <int> ordre2);

#endif